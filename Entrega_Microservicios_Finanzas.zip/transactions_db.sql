CREATE DATABASE transactions_db;
USE transactions_db;
CREATE TABLE transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  card_id INT,
  amount DECIMAL(10,2) NOT NULL,
  type ENUM('gasto','ingreso') DEFAULT 'gasto',
  category VARCHAR(50) NOT NULL,
  description TEXT,
  transaction_date DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);